# XBSL Skills — AI-инструменты для 1С:Элемент

[![Docs](https://img.shields.io/badge/docs-github_pages-108679?style=flat-square)](https://korolevpavel.github.io/xbsl-ai-skills/)
[![License](https://img.shields.io/badge/license-MIT-d68048?style=flat-square)](LICENSE)
[![Python](https://img.shields.io/badge/python-3.10%2B-2f6b94?style=flat-square)](#требования)



Набор скиллов для работы с проектами на платформе **1С:Элемент (XBSL)**.

Скиллы совместимы с [Claude Code](https://claude.ai/code) и другими AI-агентами, поддерживающими формат скиллов.

## Релиз 10.0.0.0

Актуальная линия скиллов рассчитана на **1С:Элемент 10.0**. В выпуск вошли
новые контракты метаданных и форм, журнал данных, интегрируемые приложения,
подчинённые регистры сведений, настройки списков и обновлённые сценарии
развёртывания. Сверка всех 20 скиллов с изменениями платформы, результаты
локальных тестов и облачных проверок описаны в
[`docs/element-10-audit.md`](docs/element-10-audit.md).

Проверка нативного расширения в облаке ([#197](https://github.com/korolevpavel/xbsl-ai-skills/issues/197))
и импорта внешней XSD в SOAP-сборке ([#194](https://github.com/korolevpavel/xbsl-ai-skills/issues/194))
запланирована отдельно. Пользовательские сценарии TestApp после публикации
вынесены в [#202](https://github.com/korolevpavel/xbsl-ai-skills/issues/202)–[#205](https://github.com/korolevpavel/xbsl-ai-skills/issues/205).

## Видео

Запись живого созвона: подключаем Claude Code и Codex к проекту на 1С:Элемент, работаем со скиллами, создаём объекты конфигурации и доводим всё до деплоя в 1CmyCloud.

[![YouTube](https://img.shields.io/badge/YouTube-FF0000?logo=youtube&logoColor=white)](https://youtu.be/kWJOAJ5-6EY)
[![ВКонтакте](https://img.shields.io/badge/ВКонтакте-0077FF?logo=vk&logoColor=white)](https://vk.com/video-232435421_456239040)

## Скиллы

| Скилл | Описание |
|-------|----------|
| [`xbsl-uuid`](skills/xbsl-uuid/SKILL.md) | Генерация UUID v4 для объектов конфигурации |
| [`xbsl-init`](skills/xbsl-init/SKILL.md) | Инициализация нового проекта: создаёт Проект.yaml, Проект.xbsl и Подсистема.yaml в правильном формате |
| [`xbsl-subsystem-add`](skills/xbsl-subsystem-add/SKILL.md) | Добавление новой подсистемы в существующий проект: создаёт папку и Подсистема.yaml |
| [`xbsl-explore`](skills/xbsl-explore/SKILL.md) | Разведка структуры проекта: находит проекты, подсистемы, объекты, проверяет конфликты имён |
| [`xbsl-meta-add`](skills/xbsl-meta-add/SKILL.md) | Создание объекта конфигурации (Справочник, Документ, Перечисление и др.) по описанию |
| [`xbsl-form-info`](skills/xbsl-form-info/SKILL.md) | Анализ объекта конфигурации: возвращает реквизиты, ТЧ, пространство имён и существующие формы |
| [`xbsl-form-add`](skills/xbsl-form-add/SKILL.md) | Создание формы интерфейса (ФормаОбъекта и/или ФормаСписка) для объекта конфигурации |
| [`xbsl-file-add`](skills/xbsl-file-add/SKILL.md) | Добавление файловых вложений (СписокФайлов) к объекту конфигурации: стандартные вложения, одиночный файл, категории |
| [`xbsl-image-add`](skills/xbsl-image-add/SKILL.md) | Добавление фото/изображений (аватар, фото товара, иконка) к объекту конфигурации: P5 — простая загрузка, P6 — ресайз и обрезка по кругу |
| [`xbsl-deploy`](skills/xbsl-deploy/SKILL.md) | Управление приложениями на 1С:Предприятие.Элемент: деплой, запуск, остановка, статус, merge |
| [`xbsl-playwright`](skills/xbsl-playwright/SKILL.md) | Проверка пользовательских сценариев через Playwright с сохранением тестов для повторного запуска |
| [`xbsl-pattern-register`](skills/xbsl-pattern-register/SKILL.md) | Движения по регистру накопления (приход, расход, обороты, контроль остатков) и регистру сведений (запись, удаление, срез последних) |
| [`xbsl-form-cards`](skills/xbsl-form-cards/SKILL.md) | Создание формы списка в виде карточек (матричная компоновка) для Справочников и Документов |
| [`xbsl-rename`](skills/xbsl-rename/SKILL.md) | Безопасное переименование объекта конфигурации и обновление всех ссылок во всём проекте |
| [`xbsl-form-dashboard`](skills/xbsl-form-dashboard/SKILL.md) | Создание главной страницы приложения с виджетами: KPI-счётчики, навигационные карточки, таблицы, диаграммы, карусели и бенто-сетки |
| [`xbsl-lib-connect`](skills/xbsl-lib-connect/SKILL.md) | Подключение внешней библиотеки (.xlib) к проекту: из файла, папки с исходниками или GitHub/GitLab URL |
| [`xbsl-access-set`](skills/xbsl-access-set/SKILL.md) | Управление правами доступа объектов конфигурации: сводка текущего состояния и пакетная установка КонтрольДоступа |
| [`xbsl-pattern-rls`](skills/xbsl-pattern-rls/SKILL.md) | Реализация RLS (построчный доступ): ключи доступа, обработчики разрешений, паттерны P0–P3 |
| [`xbsl-scheduled-task`](skills/xbsl-scheduled-task/SKILL.md) | Создание запланированного задания и обязательного одноимённого XBSL-обработчика |
| [`xbsl-validate`](skills/xbsl-validate/SKILL.md) | Read-only проверка YAML-файлов проекта: синтаксис, duplicate keys, общие invariants, grammar типов и coverage dispatch |

Покрытие типов `xbsl-meta-add` для 1С:Предприятие.Элемент 10.0 хранится в
каноническом registry
[`object-coverage.json`](skills/xbsl-meta-add/object-coverage.json).
Человекочитаемая матрица
[`object-coverage.md`](skills/xbsl-meta-add/object-coverage.md)
генерируется из JSON и не редактируется вручную.

Общие reference-контракты находятся в
[`references/`](skills/xbsl-meta-add/references/):
[`reference-contract.md`](skills/xbsl-meta-add/references/reference-contract.md),
[`types.md`](skills/xbsl-meta-add/references/types.md) и
[`ТабличныеЧасти.md`](skills/xbsl-meta-add/references/ТабличныеЧасти.md).

## Требования

- [Claude Code](https://claude.ai/code) или другой AI-агент, поддерживающий скиллы
- `Python 3.10+` — для работы 19 скиллов: `xbsl-uuid`, `xbsl-init`, `xbsl-subsystem-add`, `xbsl-explore`, `xbsl-meta-add`, `xbsl-form-info`, `xbsl-form-add`, `xbsl-file-add`, `xbsl-image-add`, `xbsl-deploy`, `xbsl-pattern-register`, `xbsl-form-cards`, `xbsl-rename`, `xbsl-form-dashboard`, `xbsl-lib-connect`, `xbsl-access-set`, `xbsl-pattern-rls`, `xbsl-scheduled-task` и `xbsl-validate`
- `PyYAML 6.x` — runtime-зависимость CLI `xbsl-validate`
- `Node.js` и `@playwright/test` — только для исполнения `xbsl-playwright` в consumer-проекте; в этот репозиторий Node-зависимости не устанавливаются

Во всех командах ниже `{python}` означает `python` в Windows и `python3` в macOS/Linux/WSL. Выбранный интерпретатор должен быть Python 3.10+; если сомневаешься, проверь через `{python} --version`. Выбирай команду сразу по текущей ОС, не запускай оба варианта.

## Установка

Клонируй репозиторий. Канонические исходники находятся в top-level каталоге
`skills/`; `.claude/skills` не является source mirror.

Для Claude Code скопируй содержимое source-каталога в runtime-каталог проекта:

```bash
git clone https://github.com/korolevpavel/xbsl-ai-skills.git
mkdir -p /путь/к/твоему/проекту/.claude/skills/
cp -r xbsl-ai-skills/skills/. /путь/к/твоему/проекту/.claude/skills/
```

Для Codex установи их в runtime-каталог пользователя:

```bash
mkdir -p ~/.codex/skills/
cp -r xbsl-ai-skills/skills/. ~/.codex/skills/
```

Для установки только Playwright-скилла в Codex:

```bash
mkdir -p ~/.codex/skills
cp -R xbsl-ai-skills/skills/xbsl-playwright ~/.codex/skills/
```

При обновлении заменяй папку скилла целиком: старые дополнительные файлы
не должны оставаться рядом с новой версией.

## Использование

Скиллы подхватываются автоматически. Просто опиши задачу в Claude Code:

```
Создай справочник Контрагенты с полями ИНН и КПП
```

```
Добавь перечисление статусов задачи: Новая, В работе, Завершена
```

```
Задеплой ветку main на Элемент
```

```
Добавь движения документа РасходнаяНакладная в регистр ТоварыНаСкладах
```

```
Добавь к справочнику Контрагенты возможность прикреплять файлы
```

```
Проверь через Playwright формы уже развёрнутого приложения и сохрани тесты, чтобы я мог запускать их повторно
```

Для проверки записи данных задай разрешённый объём, например:

```text
Проверь форму заказа через Playwright: <полный URL приложения>.
Разрешаю создать до двух записей за всю задачу, включая повторные попытки.
Проверь обязательные поля, сохранение и сумму после повторного открытия.
Оставь данные для просмотра. Сохрани тесты; повтор должен проверить эти же
записи без создания новых.
```

Агент использует существующую настройку Playwright или создаёт отдельный `e2e/`
в проекте приложения. Исходники приложения, готовые тесты и сессия для старта
не обязательны: достаточно URL и описания проверки. Если локального проекта нет,
агент выберет постоянный каталог для тестов. При необходимости он подготовит
Playwright, откроет браузер для вашего входа и проверит сохранённую сессию.
Пароли вводятся в браузере; содержимое сессии не нужно в чате.

Состав проверок определяется вашей задачей. Формы, поля, роли и бизнес-формулы
агент уточняет по текущему приложению; примеры не задают обязательного сценария.
CRUD, обязательность полей и вычисления проверяются, только если входят в задачу.

Результат — обычные TypeScript-тесты `@playwright/test`, отчёт о проверках и
команда повторения из каталога тестов. В сценариях с созданием и сохранением тестовых данных первое создание
выполняется в `prepare`, обычный повтор — в `verify`: он читает прежние записи.
Файл `.test-data/<task>.json` хранит их маркеры, ID и общий лимит между попытками.
Если нужна очистка, укажи это в задаче; удаляются только точные собственные записи.
Для новых сценариев агент дополнит тесты по фактическому интерфейсу.

Для следующей проверки достаточно попросить:

```text
Повтори сохранённую проверку заказа через Playwright. Используй оставленные
записи, новых не создавай.
```

## Структура проекта 1С:Элемент

Скиллы ориентируются на стандартную структуру проекта:

```
<корень>/
    <Поставщик>/
        <Проект>/
            Проект.yaml
            Проект.xbsl     # обработчики НастройкаПриложения / ОбновлениеПроекта
            <Подсистема>/
                Подсистема.yaml
                СтатусЗадачи.yaml     # объект метаданных
                СтатусЗадачи.xbsl     # методы объекта (опционально)
```

## Конфигурация xbsl-deploy

Создай файл `.env` в корне проекта:

```dotenv
# Обязательные
ELEMENT_BASE_URL=https://...
ELEMENT_CLIENT_ID=...
ELEMENT_CLIENT_SECRET=...

# Опциональные (экономят время на каждом деплое)
ELEMENT_APP_ID=...
ELEMENT_PROJECT_ID=...
ELEMENT_BRANCH=main
ELEMENT_SPACE_ID=...
```

## Разработка

```bash
# Установить зависимости
pip install -r requirements-dev.txt

# Запустить все тесты
pytest

# Тесты одного скилла
pytest tests/skills/xbsl_deploy/
pytest tests/skills/xbsl_explore/
pytest tests/skills/xbsl_form_info/
pytest tests/skills/xbsl_form_add/
pytest tests/skills/xbsl_pattern_register/

# Покрытие кода
coverage run -m pytest && coverage report
```

## GitHub Pages

Сайт собирается автоматически через GitHub Actions из `README.md` и файлов `skills/*/SKILL.md`.

Локальная сборка:

```bash
pip install -r requirements-site.txt
{python} scripts/build_site.py
```

## Добавление новых скиллов

Каждый скилл — папка в `skills/` с файлом `SKILL.md`. Frontmatter:

```yaml
---
name: имя-скилла
description: >
  Описание для триггера скилла (по нему агент решает, когда вызывать)
---
```

Для создания и улучшения скиллов рекомендуется использовать [skill-creator](https://claude.com/plugins/skill-creator), а также руководствоваться рекомендациями [agentskills.io](https://agentskills.io).

## Лицензия

[MIT](LICENSE)
